function opts=QE_Default_Opt()
    opts=struct('MultFeron',1,'SOSpow',2,'SOSpowd',2,'mix',1,'yalmip',0);
end